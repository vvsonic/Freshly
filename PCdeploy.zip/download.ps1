Set-ExecutionPolicy remotesigned
function downloadbuilder {
Invoke-WebRequest -Uri "https://github.com/vvsonic/Freshly/raw/main/PCdeploy.zip" -OutFile "C:\Freshly\PCdeploy.zip"
Expand-Archive C:\Freshly\PCdeploy.zip -DestinationPath C:\Freshly\
}
downloadbuilder